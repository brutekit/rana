public class StringC {

//    int[] arr={0};
    //Program to print
    public static void main(String[] args) {
//        System.out.println(1+2+3+4+" factorial "+(5+6+7));

//        int[] arr={1};
//        change_val(arr);
//        System.out.println(arr[0]);
//        }
//
//    public static void change_val(int[] arr) {
//        arr[0] = 3;
//        arr[0] *=3;
        String s1 = "ashish";

        String s2 = new String("ashish");

        String newstr = s1.concat(" rana");

        System.out.println(s1);

        System.out.println(newstr);

    }
}
