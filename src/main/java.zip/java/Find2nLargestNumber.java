import java.util.Arrays;

public class Find2nLargestNumber {
    public static void main(String[] args) {
        int arr[] = {10, 12, 20, 4};
//        findSecondLargestElement(arr);
        System.out.println(getSecondLargest(arr, arr.length));
    }

    static void findSecondLargestElement(int[] arr){

        Arrays.sort(arr);
        System.out.println( "Second largest element in array : " + arr[arr.length-2]);

    }


    public static int getSecondLargest(int[] a, int total){
        int temp;
        for (int i = 0; i < total; i++)
        {
            for (int j = i + 1; j < total; j++)
            {
                if (a[i] > a[j])
                {
                    temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        return a[total-2];
    }
}

